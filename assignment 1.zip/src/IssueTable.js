import React, { useState, useEffect } from "react";
import Axios from "axios";
import Modal from "react-modal";

function IssueTable({ repo, token }) {
  const [issues, setIssues] = useState([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);

  useEffect(() => {
    async function getData() {
      try {
        let url = `https://api.github.com/repos/${repo}/issues?sort=created`;
        let config = {
          headers: {
            Authorization: `Token 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`
          }
        };
        let response = await Axios.get(url, config);
        setIssues(response.data);
      } catch (error) {
        console.error(error);
      }
    }
    getData();
  }, [repo, token]);

  return (
    <div>
      <button onClick={() => setModalIsOpen(true)}>View Issues</button>
      <Modal isOpen={modalIsOpen} onRequestClose={() => setModalIsOpen(false)}>
        <h2>Issues</h2>
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            {issues.map((issue) => (
              <tr key={issue.id}>
                <td>{issue.title}</td>
                <td>{issue.created_at}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <button onClick={() => setModalIsOpen(false)}>Close</button>
      </Modal>
    </div>
  );
}

export default IssueTable;
