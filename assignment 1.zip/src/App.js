import "./styles.css";
import IssuesList from "./IssuesList.js";
import IssueTable from "./IssueTable.js";

export default function App() {
  return (
    <div className="App">
      <h1>Saurabh Pathare</h1>
      <IssuesList
        repo="facebook/react"
        token="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"
      />
      <IssueTable
        repo="facebook/react"
        token="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"
      />
    </div>
  );
}
