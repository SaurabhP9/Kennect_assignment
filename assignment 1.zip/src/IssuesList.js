import React, { useState, useEffect } from "react";
import Axios from "axios";

export default function IssuesList({ repo, token }) {
  const [issues, setIssues] = useState([]);
  const [weeks, setWeeks] = useState([]);

  useEffect(() => {
    async function fetchIssues() {
      let url = `https://api.github.com/repos/${repo}/issues?state=all`;
      let config = {
        headers: {
          Authorization: `Token ${token}`
        }
      };
      let response = await Axios.get(url, config);
      const data = await response.data;
      setIssues(data);
    }

    fetchIssues();
  }, [repo]);

  const total = issues.length;
  var openCount = 0;
  issues.forEach((issue) => {
    if (issue.state === "open") {
      openCount += 1;
    }
  });

  async function getWeeklyIssueCount(repo, token) {
    try {
      let currentDate = new Date();
      let issueCounts = {};
      for (let i = 0; i < 10; i++) {
        let startOfWeek = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate() - currentDate.getDay() - i * 7
        );
        let endOfWeek = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate() - currentDate.getDay() + 6 - i * 7
        );
        let startOfWeekIso = startOfWeek.toISOString().substring(0, 10);
        let endOfWeekIso = endOfWeek.toISOString().substring(0, 10);
        // console.log(startOfWeekIso, endOfWeekIso);
        let url = `https://api.github.com/repos/${repo}/issues?since=${startOfWeekIso}T00:00:00Z&until=${endOfWeekIso}T23:59:59Z`;
        let urlNew = `https://api.github.com/repos/${repo}/issues?since=${startOfWeekIso}T00:00:00Z&until=${endOfWeekIso}T23:59:59Z&state=open`;
        let urlClosed = `https://api.github.com/repos/${repo}/issues?since=${startOfWeekIso}T00:00:00Z&until=${endOfWeekIso}T23:59:59Z&state=closed`;
        let config = {
          headers: {
            Authorization: `Token ${token}`
          }
        };
        let response = await Axios.get(url, config);
        let responseNew = await Axios.get(urlNew, config);
        let responseClosed = await Axios.get(urlClosed, config);
        let ratio =
          (responseClosed.data.length /
            (responseNew.data.length + responseClosed.data.length)) *
          100;
        let newIssues = responseNew.data.length;
        let closedIssues = responseClosed.data.length;
        let startIssues = response.data.length;
        let closureRate = (closedIssues / (startIssues + newIssues)) * 100;
        issueCounts[startOfWeekIso] = {
          count: response.data.length,
          ratio: ratio.toFixed(2),
          closureRate: closureRate.toFixed(2)
        };
      }
      console.log(issueCounts);
      setWeeks(issueCounts);
    } catch (error) {
      console.error(error);
    }
  }
  getWeeklyIssueCount(repo, token);
  console.log(weeks);
  console.log(weeks.isArray);
  return (
    <div>
      <h2>Issues for {repo}</h2>
      <ul>
        {issues.map((issue) => (
          <li key={issue.id}>
            <a href={issue.html_url}>{issue.title}</a>
          </li>
        ))}
      </ul>
      <h3>
        Total - {total} Open - {openCount} Closed - {total - openCount}
      </h3>
      <div>
        <h2>Weekly Issue Count</h2>
        <table border="1px">
          <thead>
            <tr>
              <th>Week Start</th>
              <th>Issue Count</th>
              <th>Ratio</th>
              <th>Closure Rate</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(weeks).map(([weekStart, data]) => (
              <tr key={weekStart}>
                <td>{weekStart}</td>
                <td>{data.count}</td>
                <td>{data.ratio}</td>
                <td>{data.closureRate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
